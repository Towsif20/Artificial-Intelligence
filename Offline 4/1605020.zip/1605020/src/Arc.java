public class Arc
{
    public Variable first;
    public Variable second;

    public Arc(Variable first, Variable second)
    {
        this.first = first;
        this.second = second;
    }
}
